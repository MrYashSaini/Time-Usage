package com.example.timeutiliser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public static final String MSG = "horseselect";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner=findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        Spinner spinner2=findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.exercisehr, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(this);

        Spinner spinner3=findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,R.array.schoolhr, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);
        spinner3.setOnItemSelectedListener(this);

        Spinner spinner4=findViewById(R.id.spinner4);
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,R.array.studyhr, android.R.layout.simple_spinner_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter4);
        spinner4.setOnItemSelectedListener(this);

        Spinner spinner5=findViewById(R.id.spinner5);
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,R.array.jobhr, android.R.layout.simple_spinner_item);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter5);
        spinner5.setOnItemSelectedListener(this);

        Spinner spinner6=findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this,R.array.otherworkhr, android.R.layout.simple_spinner_item);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(adapter6);
        spinner6.setOnItemSelectedListener(this);

        Spinner spinner7=findViewById(R.id.spinner6);
        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(this,R.array.otherworkmin, android.R.layout.simple_spinner_item);
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner7.setAdapter(adapter5);
        spinner7.setOnItemSelectedListener(this);
    }
    public void calculatetime(View view){
        int usage;
        float persentage;
        Spinner spin1 = findViewById(R.id.spinner1);
        Spinner spin2 = findViewById(R.id.spinner2);
        Spinner spin3 = findViewById(R.id.spinner3);
        Spinner spin4 = findViewById(R.id.spinner4);
        Spinner spin5 = findViewById(R.id.spinner5);
        Spinner spin6 = findViewById(R.id.spinner);
        Spinner spin7 = findViewById(R.id.spinner6);

        String message = spin1.getSelectedItem().toString();
        int valueoftime = Integer.parseInt(message);
        usage = valueoftime;

        message = spin3.getSelectedItem().toString();
        valueoftime = Integer.parseInt(message);
        usage = usage+valueoftime;

        message = spin4.getSelectedItem().toString();
        valueoftime = Integer.parseInt(message);
        usage = usage+valueoftime;

        message = spin5.getSelectedItem().toString();
        valueoftime = Integer.parseInt(message);
        usage = usage+valueoftime;

        message = spin6.getSelectedItem().toString();
        valueoftime = Integer.parseInt(message);
        usage = usage+valueoftime;

        usage = usage*60;
        message = spin2.getSelectedItem().toString();
        valueoftime = Integer.parseInt(message);
        usage = usage+valueoftime;

        message = spin7.getSelectedItem().toString();
        valueoftime = Integer.parseInt(message);
        usage = usage+valueoftime;

        persentage = (float)((usage*100)/1440);

        String val = String.valueOf(persentage+"%");

        Intent intent = new Intent(this,CalculatTimeActivity.class);
        intent.putExtra(MSG,val);
        startActivity(intent);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}